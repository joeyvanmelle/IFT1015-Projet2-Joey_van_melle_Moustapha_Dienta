/* Projet 2 : Projet Homeflix

=================================================================================================

Étudiant 1 : Joey Van Melle
Matricule 1 : 20145502

Étudiant 2 : Moustapha Dienta
Matricule 2 : 20114124

=================================================================================================



 TABLE DES MATIÈRES==============================================================================
PARTIE 1 : Authentification
 	1.1. ValidateUsername
	1.2. ValidatePassword

PARTIE 2 : Recherche
	2.1. updateHeader
	2.2. searchMovies
    2.3. sortMovies
    2.4. populateSelect
    2.5. filterMovies

PARTIE 3 : Affichage
	3.1. displayMovie
	3.2. emptyList

=================================================================================================
*/



/*===============================================================================================
PARTIE 1 : Authentification
===============================================================================================*/

/***************************************************************** */
//1.1. ValidateUsername
/***************************************************************** */

// retourne le genre de l'input (username ou email)
var findInputType = function(Username) {
	inputType = null;
	for (var i = 0; i<5; i++) {
		if (Username.charAt(i) >= "A" && Username.charAt(i) <= "Z" || Username.charAt(i) >= "a" && Username.charAt(i) <= "z") {
			inputType = "username";
		} else {
			inputType = null;
			break;
		};
	};

	if (
        Username.lastIndexOf("@homeflix.ca") == Username.length - 12 && Username.lastIndexOf("@homeflix.ca") != -1
		|| Username.lastIndexOf("@homeflix.com") == Username.length - 13 && Username.lastIndexOf("@homeflix.com") != -1
        || Username.lastIndexOf("@homeflix.org") == Username.length - 13 && Username.lastIndexOf("@homeflix.org") != -1 
    ) {
		inputType = "email";
	};
	
	return(inputType);
}

//vérifie la validité d'un username
var validateIfUsername = function (Username) {
	for (var i = 5; i < Username.length; i++) {
		if (
            !(Username.charAt(i) >= "A" && Username.charAt(i) <= "Z" 
			|| Username.charAt(i) >= "a" && Username.charAt(i) <= "z"
            || Username.charAt(i) >= "0" && Username.charAt(i) <= "9")
        ) {
			return(false);
		}
	}
	return(true);
}

// vérifie la validité d'un email
var validateIfEmail = function (Username) {
	if (Username.indexOf("@") != Username.lastIndexOf("@")) {
		return(false);
	} else if (
        !((Username.charAt(0) >= "a" && Username.charAt(0) <= "z"
		|| Username.charAt(0) >= "0" && Username.charAt(0) <= "9")
		&& (Username.charAt(Username.indexOf("@")-1) >= "a" && Username.charAt(Username.indexOf("@")-1) <= "z"
        || Username.charAt(Username.indexOf("@")-1) >= "0" && Username.charAt(Username.indexOf("@")-1) <= "9"))
    ) {
		return(false);
	} else {
		for (var i = 1; i < Username.indexOf("@")-1; i++) {
			if (
                !(Username.charAt(i) >= "a" && Username.charAt(i) <= "z"
				|| Username.charAt(i) >= "0" && Username.charAt(i) <= "9"
                || Username.charAt(i) == ".")
            ) {
				return(false);
			}
		}
	} 
	return(true);
}

// valide le input username
var validateUsername = function(value) {
	switch (findInputType(value)) {
		case "username" :
			return(validateIfUsername(value));
		case "email" :
			return(validateIfEmail(value));
		default :
			return(false);
	}
}


/******************************************************************** */
//1.1. validatePassword
/******************************************************************** */

//vérifie la longueur du password
var checkPasswordLength = function(password) {
    if (password.length <= 16 && password.length >= 8 ) {
        return(true)
    } else {
        return(false)
    }
}

// vérifie la présence d'un certain type de caractère dans un mot
var checkCharacterType = function(smallAscii, bigAscii, password) {
    for (var i = 0; i < password.length; i++) {
        if (password.charAt(i) >= smallAscii && password.charAt(i) <= bigAscii) {
            return(true);
        }
    } 
    return(false);
}

// vérifie la présence de caractères spéciaux dans un mot
var checkSpecialCharacter = function(password) {
    for (var i = 0; i < password.length; i++) {
        if (
            !((password.charAt(i) >= "a" && password.charAt(i) <= "z")
            ||(password.charAt(i) >= "0" && password.charAt(i) <= "9")
            ||(password.charAt(i) >= "A" && password.charAt(i) <= "Z"))
        ) {
                return(true)
        }
    }
    return(false)
}

// vérifie la validité du password
var validatePassword = function(value) {
    if (
        checkPasswordLength(value)
        && checkCharacterType("A", "Z", value)
        && checkCharacterType("0", "9", value)
        && checkSpecialCharacter(value)
    ) {
        return(true)
    } else {
        return(false)
    }
}

/*===============================================================================================
PARTIE 2 : Recherche
===============================================================================================*/

/***************************************************************** */
//2.1. updateHeader
/***************************************************************** */

//Entre la valeur du username dans le champs prévu à cet effet
var updateHeader = function(username) {
    document.getElementById("username").innerHTML = username;
}

/***************************************************************** */
//2.2. searchMovies
/***************************************************************** */


// trie les films dont les caractères sont présents dans la barre de recherche
var searchMovies = function(movies, searchValue) {
	emptyList(); // voir fin du programme 
	var isCharacterPresent = function(movieName, letter) {
		for (var i = 0; i < movieName.length; i++) {
			if (movieName.charAt(i).toUpperCase() == letter.toUpperCase()) {
				return true;
			}
		}
		return(false);
	}

    results = [];
    movieLoop : for (var i = 0; i < movies.length; i++) {
		for (var j = 0; j < searchValue.length; j++) {
			if (isCharacterPresent(movies[i].title, searchValue.charAt(j)) == false) {
				continue movieLoop;
			}
		}
		results.push(movies[i]);
	}
	return(results);
}

/***************************************************************** */
//2.3. sortMovies
/***************************************************************** */

// trie les films en ordre croissant en fonction de leur titre
var sortMovies = function(movies, isAscending) {	
	movies.sort(function(a, b) {
		if ((a.title).toUpperCase() < (b.title).toUpperCase()) {
			return(-1);
		} else if ((a.title).toUpperCase() == (b.title).toUpperCase()) {
			return(0);
		} else if ((a.title).toUpperCase() > (b.title).toUpperCase()){
			return(1);
		};
	});
	if (isAscending == true) {
		return(movies);
	} else if (isAscending == false) {
		movies.reverse();
		return(movies);
	}
};
	
/***************************************************************** */
//2.4. populateSelect
/***************************************************************** */

// retourne une liste de genre commun aux films rechrechés
var populateSelect = function(movies) {
	var output = [movies[0].genres[0]];
	for (var i = 1; i < movies.length; i++) {
		genresLoop: for (var j = 0; j < movies[i].genres.length; j++) {
			for (var k = 0; k < output.length; k++) {
				if (movies[i].genres[j] == output[k]) {
					continue genresLoop;
				} 
			}
			output.push(movies[i].genres[j]);
		}
	}
	return(output);
}

/***************************************************************** */
//2.5. filterMovies
/***************************************************************** */

// retourne une liste de film en fonction d'un genre défini
var filterMovies = function(movies, genreFilter) { 
	var outputFilterMovies = [];
	for (var i = 0; i < movies.length; i++) {
		for (var j = 0; j < movies[i].genres.length; j++) {
			if (movies[i].genres[j] == genreFilter) {
				outputFilterMovies.push(movies[i]);
			}
		}
	}
	return(outputFilterMovies);
}

/*===============================================================================================
PARTIE 3 : Affichage
===============================================================================================*/

/***************************************************************** */
//3.1. displayMovie
/***************************************************************** */

// crée une balise li et y ajoute sa classe c-main_item o-layout_item u-1/4
var liFunction = function(movie){
	var newChild = document.createElement("li");
	var parentElement = document.getElementsByClassName("c-main_list o-layout o-wrapper -gutter-small")[0];
	parentElement.appendChild(newChild);
	newChild.className = "c-main_item o-layout_item u-1/4";
	newChild.appendChild(div1Function(movie));
	newChild.appendChild(h2Title(movie))
};

// Crée une balise div et y ajoute sa classe  c-main_item_card
var div1Function = function(movie){
	var newChild = document.createElement("div");
	newChild.className = "c-main_item_card";
	newChild.appendChild(div2Function(movie));
	return(newChild);
}

// Crée une balise h2 et y ajoute le titre du film, ainsi que sa classe c-main_item_title
var h2Title = function(movie) {
	var newChild = document.createElement("h2");
	newChild.className = "c-main_item_title";
	newChild.title = movie.title;
	newChild.innerHTML = movie.title;
	return(newChild);
}

// Crée une balise div et y ajoute sa classe c-main_item_cover -red
var div2Function = function(movie) {
	var newChild = document.createElement("div");
	newChild.className = "c-main_item_cover -red";
	newChild.appendChild(itemPreviewFunction(movie));
	newChild.appendChild(div3Function(movie));
	return(newChild);
}

// Crée une balise p et y ajoute sa classe c-main_item_preview
var itemPreviewFunction = function(movie) {
	var newChild = document.createElement("p");
	newChild.className = "c-main_item_preview";
	newChild.innerHTML = itemInnerHtml(movie);
	return(newChild);
}

// Crée le innerHtml de la balise p c-main_item_preview, soit un acronyme du film
var itemInnerHtml = function(movie) {
	var text = "";
	var splitTitle = movie.title.split(" ");
	for (var i = 0; i < 3; i++) {
		if (splitTitle.length < i) {
			break;
		} else {
			text = text + splitTitle[i].charAt(0);
		}
	}
	text = text.toUpperCase();
	return(text);
}

// crée une balise div et y ajoute sa classe c-main_item_details
var div3Function = function(movie) {
	var newChild = document.createElement("div");
	newChild.className = "c-main_item_details";
	detailsElement(movie, newChild);
	return(newChild);
}


// Fonction qui retourne une chaine de charactère contenant les genres d'un film 
var genresMovie = function(movie){

	var output = "";
	for (var i = 0; i < movie.genres.length; i++) {
		if (i == 0 ) {
			output = movie.genres[i];
		} else {
			output = output + ", " + movie.genres[i];
		}
	}
	return(output);
}

// empêche le snyopsis de faire déborder le contenu
	var cutOverview = function(movie){
		var text = movie.overview;
		if (text.length > 100) {
			text = text.slice(0, 100) + "..."
		}
		return(text);
	}

// fonction qui change le runtime en heure
	var runtime = function(movie) {
		var time = movie.runtime;
		var min = time%60;
		var hour = (time - time%60)/60;
		return(hour + "h" + min + "min");
	}

// Fonction qui génère tout les éléments à l'intérieur du div c-main_item_details
var detailsElement = function(movie, detailsDiv) {
	
	//Création des balises
	var child = [
		document.createElement("h3"), //0
		document.createElement("p"),  //1
		document.createElement("h3"), //2
		document.createElement("p"),  //3
		document.createElement("h3"), //4
		document.createElement("p"),  //5
		document.createElement("h3"), //6
		null,		
		document.createElement("h3"), //8
		null,
		document.createElement("h3"), //10
		document.createElement("span"), //11
		document.createElement("span"), //12
		document.createElement("span"), //13
	];

	// Insertion des classes
	for (var i = 0; i <= 10; i += 2) {
		child[i].className = "c-main_item_header"
	};
	for (var j = 1; j <= 5; j += 2) {
		child[j].className = "c-main_item_text"
	};
	for (var k = 11; k <= 13; k++) {
		child[k].className = "c-main_item_span"
	};

	// Tableau des NodeTexts
	var insideText = [
		"Title :",						//0
		movie.title,//....................1
		"Genre :",						//2
		genresMovie(movie), //............3
		"Synopsis :",					//4
		cutOverview(movie),	//................5
		"Length :",						//6
		null,	//........................7
		"Language :",					//8
		null,	//........................9
		"Rating :",					   //10
		runtime(movie),	//.......11
		movie.language.toUpperCase(),  //12
		movie.rating + "/10",	//.......13
	]

	// Met les NodeTexts avec leur parent
		for (var l = 0; l <= 13; l++) {
			if (l == 7 || l == 9) { continue; }
			else {
				var textNode = document.createTextNode(insideText[l]);
				var textNodeContainer = child[l];
				textNodeContainer.append(textNode);
			}
		}



	// Met les child element avec leur parent
	child[6].appendChild(child[11]);
	child[8].appendChild(child[12]);
	child[10].appendChild(child[13]);
	for (var m = 0; m <= 10; m++) {
		if (m == 7 || m == 9) { continue; }
		else {
			detailsDiv.appendChild(child[m]);
		}
	}
}

// fonction qui permet d'afficher un film, soit son objet JS

var displayMovie = function(movie) {
	var outputDisplayMovie = {};
	outputDisplayMovie.title = movie.title;
	outputDisplayMovie.genres = movie.genres;
	outputDisplayMovie.element = liFunction(movie);
	return(outputDisplayMovie);
}

/***************************************************************** */
//3.2. emptyList
/***************************************************************** */

/* 
	La fonction emptyList a été ajoutée bien qu'elle n'était pas demandée. Lorsque l'on effectuait une deuxième
	recherche dans la barre de recherche, les objects de la recherche précédente n'étaient pas effacés. C'est pourquoi
	cette fonction a été rajoutée.
*/

// Fonction qui efface les objets créé lors de la recherche précédente
var emptyList = function() {
	List = document.getElementsByClassName("c-main_list o-layout o-wrapper -gutter-small")[0];
	List.innerHTML = null;
}
